<?php
include 'callAPI.php';
include 'admin_token.php';
$contentBodyJson = file_get_contents('php://input');
$content = json_decode($contentBodyJson, true);

$baseUrl = getMarketplaceBaseUrl();
$admin_token = getAdminToken();
$userToken = $_COOKIE["webapitoken"];
$customFieldPrefix = getCustomFieldPrefix();

$card_id = $content['card_id'];

// Query to get marketplace id
$url = $baseUrl . '/api/v2/marketplaces/';
$marketplaceInfo = callAPI("GET", null, $url, false);

require_once('stripe-php/init.php');
\Stripe\Stripe::setApiKey('sk_test_51INpZ6LpiOi48zknrweuYlbv7lThIzaBNcn4dgyXSXZHNeAolscJsVo9YdHYmbH4EPW1ty4ByRicFi5KvAPMjC5V00CatSNcjd');

$plan_id='';
$plan_data= [];
foreach ($marketplaceInfo['CustomFields'] as $cf) {
    if ($cf['Name'] == 'plan_id' && substr($cf['Code'], 0, strlen($customFieldPrefix)) == $customFieldPrefix) {
        $plan_id = $cf['Values'][0];
    }
}
if (!empty($plan_id)) {
    //create customer
    $customer = \Stripe\Customer::create([
        'name'=> 'Onoda Sakamichi',
        'description' => 'sample description',
        'email' => 'nmfnavarro@gmail.com'
        //'payment_method' => $payment
    ]);


    $customer_id =  $customer->id;

    echo json_encode(['result' =>  $customer_id]);

    // $paymethod = \Stripe\Source::create([
    //     'customer' => $customer_id,
    
    // ]);    


    // $paymethod = \Stripe\SetupIntent::create([
    //     'payment_method_types' => ['card'],
    //     'customer' => $customer_id,
    //     'confirm' => true,
    //     'payment_method' => $card_id

    // ]);

    // $payment = $paymethod->id;



//     $stripe = new \Stripe\StripeClient(
//         'sk_test_51INpZ6LpiOi48zknrweuYlbv7lThIzaBNcn4dgyXSXZHNeAolscJsVo9YdHYmbH4EPW1ty4ByRicFi5KvAPMjC5V00CatSNcjd'
//       );
// //attach the payment method to the customer
//         $attach = $stripe->paymentMethods->attach(
//         $card_id,
//         ['customer' => $customer_id]
//         );

//    $source = $attach->id;
//    echo json_encode(['result' => $attach]);



    //create subscription
    //  $subscription = \Stripe\Subscription::create([
       
    //     'customer' => $customer_id,
    //      'items' => [
    //          ['price' => $plan_id ]
    //      ]
    // ]);     

    // echo json_encode(['result' => $subscription]);

 }
?>

